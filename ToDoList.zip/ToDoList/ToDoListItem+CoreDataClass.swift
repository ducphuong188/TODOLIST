//
//  ToDoListItem+CoreDataClass.swift
//  ToDoList
//
//  Created by macbook on 15/07/2023.
//
//

import Foundation
import CoreData

@objc(ToDoListItem)
public class ToDoListItem: NSManagedObject {

}
