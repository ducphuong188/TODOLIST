//
//  ToDoListItem+CoreDataProperties.swift
//  ToDoList
//
//  Created by macbook on 15/07/2023.
//
//

import Foundation
import CoreData


extension ToDoListItem {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ToDoListItem> {
        return NSFetchRequest<ToDoListItem>(entityName: "ToDoListItem")
    }

    @NSManaged public var name: String?
    @NSManaged public var time: Date?

}

extension ToDoListItem : Identifiable {

}
